<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sell Your Car</title>
    <link rel="shortcut icon" href="images/mini fig.png" type="image/x-icon" />
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header>
    <h1>Vintage Car</h1>
		</header>
		<!-- Page-level main content -->
		<main>
			<section>
				<h2>Thank You for giving your precious Feedback...!</h2>
                <h3>Visit Again....<h3>
			</section>
		</main>
		<!-- Page-level footer -->
		<footer>
              <p>&copy; 2024 SELLME company</p>
		</footer>
	</body>
</html>
